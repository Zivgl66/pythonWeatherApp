#include <stdio.h>
#ifndef STACK_H
#define STACK_H

typedef Stack;

Stack* CreateStack(size_t stack_capacity, size_t size);
void DestroyStack(Stack *s);
void PopStack(Stack *s);
void PushStack(Stack *s, (void *) new_elm);
(void *) PeekStack(const Stack *s);
size_t SizeStack(const Stack *s);
int IsEmptyStack(const Stack *s);
size_t CapacityStack(const Stack *s);

#endif
